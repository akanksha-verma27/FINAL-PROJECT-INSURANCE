package com.java.ips;

import java.io.Serializable;

public class Insurance_Plans implements Serializable{

	private int plan_id;
	private String insurance_id;
	private double premium_Amount;
	private String coverage_Amount;
	private String disease;
	
	public Insurance_Plans() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Insurance_Plans(int plan_id, String insurance_id, double premium_Amount, String coverage_Amount,
			String disease) {
		super();
		this.plan_id = plan_id;
		this.insurance_id = insurance_id;
		this.premium_Amount = premium_Amount;
		this.coverage_Amount = coverage_Amount;
		this.disease = disease;
	
     
	}
    
	public int getPlan_id() {
		return plan_id;
	}

	public void setPlan_id(int plan_id) {
		this.plan_id = plan_id;
	}

	public String getInsurance_id() {
		return insurance_id;
	}

	public void setInsurance_id(String insurance_id) {
		this.insurance_id = insurance_id;
	}

	public double getPremium_Amount() {
		return premium_Amount;
	}

	public void setPremium_Amount(double premium_Amount) {
		this.premium_Amount = premium_Amount;
	}

	public String getCoverage_Amount() {
		return coverage_Amount;
	}

	public void setCoverage_Amount(String coverage_Amount) {
		this.coverage_Amount = coverage_Amount;
	}

	public String getDisease() {
		return disease;
	}
    
	public void setDisease(String disease) {
		this.disease = disease;
	}
	
	@Override
	public String toString() {
		return "Insurance_Plans [plan_id=" + plan_id + ", insurance_id=" + insurance_id + ", premium_Amount="
				+ premium_Amount + ", coverage_Amount=" + coverage_Amount + ", benefits=" + disease +  "]";
	}

}

